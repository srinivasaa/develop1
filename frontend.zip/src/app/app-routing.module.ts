import {Routes} from '@angular/router';

import {ProductProfileSelectorComponent} from './product-profile-selector/product-profile-selector.component';

export const Approutes: Routes = [
  {
    path: '',
    component: ProductProfileSelectorComponent
  },
];
