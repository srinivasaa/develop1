// src/app/_models/mock-data.ts
export interface Product {
  id: number;
  name: string;
}

export interface Attribute {
  name: string;
  format: string;
  variable: string;
}

export interface Profile {
  id: number;
  name: string;
  productId: number;
  attributes: Attribute[];
}

export interface Value {
  id: number;
  name: string;
}

export const PRODUCTS: Product[] = [
  {id: 1, name: 'Product 1'},
  {id: 2, name: 'Product 2'},
  {id: 3, name: 'Product 3'},
];

export const AttributeValues: Value[] = [
  {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'},
  {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'},
  {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'}, {id: 1, name: 'value 1'},
  {id: 2, name: 'Leng 2'},
  {id: 3, name: 'Size 3'},






];

export const PROFILES: Profile[] = [
  {
    id: 1,
    name: 'Profile 1',
    productId: 1,
    attributes: [
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},
      {name: 'Attribute 1', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 3', format: 'Date', variable: ''},


    ]
  },
  {
    id: 2,
    name: 'Profile 2',
    productId: 1,
    attributes: [
      {name: 'Attribute 2', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 2', format: 'Date', variable: ''},
      {name: 'Attribute 2', format: 'String', variable: ''},
      {name: 'Attribute 2', format: 'Number', variable: ''},
      {name: 'Attribute 2', format: 'Date', variable: ''},
      {name: 'Attribute 2', format: 'String', variable: ''},
    ]
  },
  {
    id: 3,
    name: 'Profile 3',
    productId: 2,
    attributes: [
      {name: 'Attribute 7', format: 'String', variable: ''},
      {name: 'Attribute 8', format: 'Number', variable: ''},
      {name: 'Attribute 9', format: 'Date', variable: ''}
    ]
  },
  {
    id: 4,
    name: 'Profile 4',
    productId: 2,
    attributes: [
      {name: 'Attribute 10', format: 'String', variable: ''},
      {name: 'Attribute 11', format: 'Number', variable: ''},
      {name: 'Attribute 12', format: 'Date', variable: ''}
    ]
  },
  {
    id: 5,
    name: 'Profile 5',
    productId: 3,
    attributes: [
      {name: 'Attribute 13', format: 'String', variable: ''},
      {name: 'Attribute 14', format: 'Number', variable: ''},
      {name: 'Attribute 15', format: 'Date', variable: ''}
    ]
  },
  {
    id: 6,
    name: 'Profile 6',
    productId: 3,
    attributes: [
      {name: 'Attribute 16', format: 'String', variable: ''},
      {name: 'Attribute 17', format: 'Number', variable: ''},
      {name: 'Attribute 18', format: 'Date', variable: ''}
    ]
  }
];
