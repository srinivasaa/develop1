import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProductProfileSelectorComponent } from './product-profile-selector.component';

describe('ProductProfileSelectorComponent', () => {
  let component: ProductProfileSelectorComponent;
  let fixture: ComponentFixture<ProductProfileSelectorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProductProfileSelectorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProductProfileSelectorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
