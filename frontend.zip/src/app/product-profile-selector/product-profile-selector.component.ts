import {AfterViewInit, Component, OnInit, ViewChild} from '@angular/core';
import {Attribute, AttributeValues, Product, PRODUCTS, Profile, PROFILES, Value} from '../mock-data';
import {DataTableDirective} from "angular-datatables";
import {Subject} from "rxjs";
import {ColumnMode} from "@swimlane/ngx-datatable";

@Component({
  selector: 'app-product-profile-selector',
  templateUrl: './product-profile-selector.component.html',
  styleUrls: ['./product-profile-selector.component.css']
})
export class ProductProfileSelectorComponent implements OnInit, AfterViewInit {
  products: Product[] = PRODUCTS;
  profiles: Profile[] = PROFILES
  filteredProfiles: Profile[] = [];
  selectedProduct: number;
  selectedProfile: Profile;
  selectedProfileId: number;
  attributeValues: Value[] = AttributeValues;
  filteredAttributeValues: Value[] = AttributeValues;
  filteredAttributes: Attribute[] = [];
  searchText: string = '';
  protected readonly ColumnMode = ColumnMode;

  constructor() {
  }

  ngAfterViewInit(): void {

  }

  ngOnInit(): void {
    const storedProfiles = localStorage.getItem('PROFILES');
    if (storedProfiles) {
      this.profiles = JSON.parse(storedProfiles);
    }
  }

  onProductChange() {
    this.filteredProfiles = this.profiles.filter(profile => profile.productId == this.selectedProduct);
  }

  onProfileChange() {
    console.log(this.selectedProfileId);
    this.selectedProfile = this.profiles.find(profile => profile.id == this.selectedProfileId);
    this.filteredAttributes = this.selectedProfile.attributes.slice(); // Copy the attributes to filteredAttributes
  }

  allowDrop(event) {
    event.preventDefault();
  }

  dragStart(event, attributeValue) {
    event.dataTransfer.setData('text/plain', attributeValue.name);
  }

  drop(event, attribute): void {
    console.log(attribute);
    attribute.variable = event.dataTransfer.getData('text/plain');
  }

  search() {
    this.filteredAttributeValues = this.attributeValues.filter(attributeValue =>
      attributeValue.name.toLowerCase().includes(this.searchText.toLowerCase())
    );
  }

  edit(value: any) {
    console.log(value);

  }

  saveChanges() {
    const index = this.profiles.findIndex(profile => profile.id === this.selectedProfile.id);
    this.profiles[index] = this.selectedProfile;
    localStorage.setItem('PROFILES', JSON.stringify(this.profiles)); // Save updated profiles in local storage
    console.log('Updated Profiles: ', this.profiles);
    alert("Saved");
  }

  updateFilter(event) {
    const val = event.target.value.toLowerCase();
    const temp = this.selectedProfile.attributes.filter((attribute) => {
      return attribute.name.toLowerCase().indexOf(val) !== -1 || !val;
    });
    this.filteredAttributes = temp;
  }

}
